# CHANGELOG

## 1.1.0

- Add configuration

## 1.0.0

- Add Mods
- Create Icon
