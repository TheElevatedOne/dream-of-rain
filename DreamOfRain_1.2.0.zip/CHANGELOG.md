# CHANGELOG

## 1.2.0

- Add Arsonist - a new character
- Add Ping Improvements
- Add NoMoreMath
- Add CollapseDisplay

## 1.1.0

- Add configuration

## 1.0.0

- Add Mods
- Create Icon
